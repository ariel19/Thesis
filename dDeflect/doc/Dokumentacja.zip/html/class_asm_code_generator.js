var class_asm_code_generator =
[
    [ "Instructions", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8", [
      [ "POP", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8aefdb39a4c7286afcecf0e8a7435fce6a", null ],
      [ "PUSH", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8a73dabe4437725eedc05a1824a2c31550", null ],
      [ "MOV", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8a17b32100aef1fc19670be7fd58bc85df", null ],
      [ "JMP", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8a152b9af76a9e7dd95d9da277b69fdd95", null ],
      [ "CALL", "class_asm_code_generator.html#a975bb037f383eb14e8f21acc7c4cd9a8aca3547acb9162b49fb4a6594ed9b3030", null ]
    ] ],
    [ "AsmCodeGenerator", "class_asm_code_generator.html#ae10580c9dd3ea1e0de47a50ad92143ea", null ],
    [ "call_const", "class_asm_code_generator.html#aa4989922344c4dc9ccfa937508915c3d", null ],
    [ "call_reg", "class_asm_code_generator.html#a3bf9daed908df41eeec6031db9de2aae", null ],
    [ "get_reg", "class_asm_code_generator.html#ab578154f2a3d0ef023c8f6a302a3f565", null ],
    [ "jmp_reg", "class_asm_code_generator.html#ac196b01980e9de00bf6854baed99a1a2", null ],
    [ "mov_reg_const", "class_asm_code_generator.html#a955d06de335abb5491727e690bb4cc85", null ],
    [ "pop_regs", "class_asm_code_generator.html#a75bbaa5a9453e6997afdfa14e9471362", null ],
    [ "pop_regs", "class_asm_code_generator.html#aaed0677c22b8a46586286483ed11f205", null ],
    [ "push_regs", "class_asm_code_generator.html#a76f8c73f9210eb61a8001c017c0cd4f1", null ],
    [ "push_regs", "class_asm_code_generator.html#a25ee0b50bb215502d9b61a753086f184", null ],
    [ "instructions", "class_asm_code_generator.html#ab017616dbde9a998807080cbc0bff89a", null ],
    [ "regs_x64", "class_asm_code_generator.html#ab87fdfb10a73e4a7e684b644722408a8", null ],
    [ "regs_x86", "class_asm_code_generator.html#a112155891be9747ebf0dd45301031053", null ]
];