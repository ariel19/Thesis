var class_binary_file =
[
    [ "BinaryFile", "class_binary_file.html#a1afe5dffc5edf5f25ea22deef606eb4b", null ],
    [ "~BinaryFile", "class_binary_file.html#a8ff1b2e140421fd040bff0854c1322ff", null ],
    [ "getData", "class_binary_file.html#a5ffee8a6230cf3c82cf6ee0e9fb53048", null ],
    [ "is_valid", "class_binary_file.html#a6007435bc4451bb80a3169d977f4f125", null ],
    [ "is_x64", "class_binary_file.html#a36b7998c72bbee68ab492d93368c14ca", null ],
    [ "is_x86", "class_binary_file.html#aa7d43cde4ab8cc9723d2b5c769719bd9", null ],
    [ "b_data", "class_binary_file.html#acdfdb2fae63d8395dfa899be21bd8036", null ],
    [ "parsed", "class_binary_file.html#ae16774932979ddb6d57b46b3c387a159", null ]
];