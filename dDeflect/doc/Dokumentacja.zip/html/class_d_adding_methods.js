var class_d_adding_methods =
[
    [ "InjectDescription", "class_d_adding_methods_1_1_inject_description.html", "class_d_adding_methods_1_1_inject_description" ],
    [ "OEPWrapper", "class_d_adding_methods_1_1_o_e_p_wrapper.html", "class_d_adding_methods_1_1_o_e_p_wrapper" ],
    [ "ThreadWrapper", "class_d_adding_methods_1_1_thread_wrapper.html", "class_d_adding_methods_1_1_thread_wrapper" ],
    [ "TrampolineWrapper", "class_d_adding_methods_1_1_trampoline_wrapper.html", "class_d_adding_methods_1_1_trampoline_wrapper" ],
    [ "Wrapper", "class_d_adding_methods_1_1_wrapper.html", "class_d_adding_methods_1_1_wrapper" ],
    [ "ArchitectureType", "class_d_adding_methods.html#a7d062c443c04f37689dbececc36cf4a3", [
      [ "BITS32", "class_d_adding_methods.html#a7d062c443c04f37689dbececc36cf4a3a19c324fc35adafffc05d643f63e8eb5e", null ],
      [ "BITS64", "class_d_adding_methods.html#a7d062c443c04f37689dbececc36cf4a3a316bc10be99a2862edd96d24e0d150d9", null ]
    ] ],
    [ "CallingMethod", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0", [
      [ "OEP", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0a1f69192f5c5359619a4410d97d1655be", null ],
      [ "Thread", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0ad97477d6d8a838ead9348185bb5b6742", null ],
      [ "Trampoline", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0ad113494f870355ce123dfb74beea602d", null ],
      [ "INIT", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0afaee4ca3c30ee18148ce3ada37466498", null ],
      [ "INIT_ARRAY", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0a8c11d1b1290b76379bf90434c0e83f4a", null ],
      [ "CTORS", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0a02f11aadd3ab1bd5b7ccd3040d8a0075", null ],
      [ "TLS", "class_d_adding_methods.html#a8b52c07f1794d8c6cdd6f9b98be2bbf0a099d7d04319e5191b7473e016c55e320", null ]
    ] ],
    [ "SystemType", "class_d_adding_methods.html#a14e87405d457c7c3671eca0e74b3f327", [
      [ "Windows", "class_d_adding_methods.html#a14e87405d457c7c3671eca0e74b3f327aaea23489ce3aa9b6406ebb28e0cda430", null ],
      [ "Linux", "class_d_adding_methods.html#a14e87405d457c7c3671eca0e74b3f327aedc9f0a5a5d57797bf68e37364743831", null ]
    ] ],
    [ "DAddingMethods", "class_d_adding_methods.html#aa00f1f94760a223807193314537b6651", null ],
    [ "arch_type", "class_d_adding_methods.html#aa368755d8aba57f3a92877d1fbe925b3", null ],
    [ "callingMethods", "class_d_adding_methods.html#a4c746112dd790909f893063563cd7877", null ],
    [ "file", "class_d_adding_methods.html#a87bdff1dd02ac26df6c10648fe406cd9", null ]
];