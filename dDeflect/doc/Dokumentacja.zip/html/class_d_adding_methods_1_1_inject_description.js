var class_d_adding_methods_1_1_inject_description =
[
    [ "adding_method", "class_d_adding_methods_1_1_inject_description.html#acea7bb1b146f912703e30039f200b538", null ],
    [ "change_x_only", "class_d_adding_methods_1_1_inject_description.html#a8046652b0fae10f8e04e0678fd5961fd", null ],
    [ "cm", "class_d_adding_methods_1_1_inject_description.html#a71f8164f1c9e433b6b22b5480dc5f066", null ],
    [ "saved_fname", "class_d_adding_methods_1_1_inject_description.html#ab12b0b3cab069790363224252a2a9b22", null ]
];