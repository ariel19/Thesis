var class_d_adding_methods_1_1_thread_wrapper =
[
    [ "sleep_time", "class_d_adding_methods_1_1_thread_wrapper.html#a6125379d0d3674ddab3848951ed9ba16", null ],
    [ "thread_actions", "class_d_adding_methods_1_1_thread_wrapper.html#a17fc0920f489293031ab914cb8d36ba7", null ]
];