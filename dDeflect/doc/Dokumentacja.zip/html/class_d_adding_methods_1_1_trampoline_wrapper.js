var class_d_adding_methods_1_1_trampoline_wrapper =
[
    [ "tramp_action", "class_d_adding_methods_1_1_trampoline_wrapper.html#ad8edbc5d2b33a52be1bcaf5a4437339c", null ]
];