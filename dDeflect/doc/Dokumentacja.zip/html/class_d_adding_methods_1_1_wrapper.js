var class_d_adding_methods_1_1_wrapper =
[
    [ "WrapperType", "class_d_adding_methods_1_1_wrapper.html#acb6db05ae66304ccd8b53c49221e0b09", [
      [ "Handler", "class_d_adding_methods_1_1_wrapper.html#acb6db05ae66304ccd8b53c49221e0b09a0bb4c52ba15ca41d65967d91840c66fb", null ],
      [ "Method", "class_d_adding_methods_1_1_wrapper.html#acb6db05ae66304ccd8b53c49221e0b09a4c3880bb027f159e801041b1021e88e8", null ],
      [ "Thread", "class_d_adding_methods_1_1_wrapper.html#acb6db05ae66304ccd8b53c49221e0b09ad97477d6d8a838ead9348185bb5b6742", null ],
      [ "Helper", "class_d_adding_methods_1_1_wrapper.html#acb6db05ae66304ccd8b53c49221e0b09aec34cd6f057c4737bfc8df7590ecb87e", null ]
    ] ],
    [ "~Wrapper", "class_d_adding_methods_1_1_wrapper.html#aa4f7725137a5389ee76db0bd8590243e", null ],
    [ "read", "class_d_adding_methods_1_1_wrapper.html#ad8951e3aea612be776608e90eebca99b", null ],
    [ "registerTypes", "class_d_adding_methods_1_1_wrapper.html#a23c5ce701c9c72ceeaa1a51a66469d1f", null ],
    [ "registerTypes", "class_d_adding_methods_1_1_wrapper.html#a749f28211834a2f0341ef2c41ea52e4f", null ],
    [ "write", "class_d_adding_methods_1_1_wrapper.html#a58262eb13d7aba4be0891d82f5ee0cc2", null ],
    [ "allowed_methods", "class_d_adding_methods_1_1_wrapper.html#a7365bd260c137feafcdc7abde67ffedc", null ],
    [ "arch_type", "class_d_adding_methods_1_1_wrapper.html#aa4f2505d3abca144ceaae01692ab2982", null ],
    [ "code", "class_d_adding_methods_1_1_wrapper.html#a1280984042d8167b8207d33488189415", null ],
    [ "description", "class_d_adding_methods_1_1_wrapper.html#a1f27a97876d639a2e39482c4a3a6d274", null ],
    [ "detect_handler", "class_d_adding_methods_1_1_wrapper.html#aaa3fdb9659e74c099359cc0af48e4233", null ],
    [ "dynamic_params", "class_d_adding_methods_1_1_wrapper.html#ac11ddb3500c96e6175c4b939cc726d4d", null ],
    [ "name", "class_d_adding_methods_1_1_wrapper.html#a41c5e8fdd7bde2f8610d2d499ae8f4b3", null ],
    [ "registerTypes", "class_d_adding_methods_1_1_wrapper.html#aa6b67c45d00922b17d7934cdafb98799", null ],
    [ "ret", "class_d_adding_methods_1_1_wrapper.html#ae7d3f4a32619b51a7f0f0e53fbc87d38", null ],
    [ "static_params", "class_d_adding_methods_1_1_wrapper.html#a915ee3066596bebdc8f2c21c6cf5b9bc", null ],
    [ "system_type", "class_d_adding_methods_1_1_wrapper.html#ae298975da4ef638bef00c8277501eddc", null ],
    [ "used_regs", "class_d_adding_methods_1_1_wrapper.html#aba0dc1a5f9addd4317b87e92fb2eb0db", null ],
    [ "wrapper_type", "class_d_adding_methods_1_1_wrapper.html#aaa1e1c8e0902c6241c714498dc9e5316", null ],
    [ "wrapperTypes", "class_d_adding_methods_1_1_wrapper.html#abcab95b43aa54857c51d47c8cb283f7b", null ]
];