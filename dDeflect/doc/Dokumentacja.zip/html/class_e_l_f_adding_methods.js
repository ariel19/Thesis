var class_e_l_f_adding_methods =
[
    [ "PlaceholderMnemonics", "class_e_l_f_adding_methods.html#a666b28eeb9569323a4f697d37c6a1022", [
      [ "DDETECTIONHANDLER", "class_e_l_f_adding_methods.html#a666b28eeb9569323a4f697d37c6a1022aa229d6072e720d4ea51a461305a77419", null ],
      [ "DDETECTIONMETHOD", "class_e_l_f_adding_methods.html#a666b28eeb9569323a4f697d37c6a1022a27bbeb27ba0c0ff952f0fd2d60ae393d", null ],
      [ "DDRET", "class_e_l_f_adding_methods.html#a666b28eeb9569323a4f697d37c6a1022a5f7c52080f7e0204b8d872cba032e24d", null ]
    ] ],
    [ "PlaceholderTypes", "class_e_l_f_adding_methods.html#a7058ae8ed3ce82783edb1eb0a44c1150", [
      [ "PARAM_PRE", "class_e_l_f_adding_methods.html#a7058ae8ed3ce82783edb1eb0a44c1150a52f564497e8e79fb9faf8ef2e4e727ba", null ],
      [ "PARAM_POST", "class_e_l_f_adding_methods.html#a7058ae8ed3ce82783edb1eb0a44c1150a64a5bcb12c5350fc77bead500da05d04", null ],
      [ "PLACEHOLDER_PRE", "class_e_l_f_adding_methods.html#a7058ae8ed3ce82783edb1eb0a44c1150a7f3e363cf91446c37876c5842a13ed14", null ],
      [ "PLACEHOLDER_POST", "class_e_l_f_adding_methods.html#a7058ae8ed3ce82783edb1eb0a44c1150ac48d0ec9c86b18c729c51ca6742cbf19", null ]
    ] ],
    [ "ELFAddingMethods", "class_e_l_f_adding_methods.html#a49ddea5561dbff8a787d586e58d70d22", null ],
    [ "~ELFAddingMethods", "class_e_l_f_adding_methods.html#a374088ad2597fa11063b5a19bae0ffec", null ],
    [ "compile", "class_e_l_f_adding_methods.html#a2d8f6c6b99d1f3e22d9196cd70e9c017", null ],
    [ "fill_params", "class_e_l_f_adding_methods.html#a173aef7c3ca6dfd00a26676b7b1c799c", null ],
    [ "fill_placeholders", "class_e_l_f_adding_methods.html#a1c71c7b3681912661e529ac4878dc8d8", null ],
    [ "get_addresses", "class_e_l_f_adding_methods.html#aea9b58dda2bc9b6216a01c3970b1f214", null ],
    [ "get_file_offsets_from_opcodes", "class_e_l_f_adding_methods.html#a2f92b80d3e5470890c1d78cb8575c13d", null ],
    [ "secure_elf", "class_e_l_f_adding_methods.html#acaa41aa5ab101bb4fa0e23a3029020ad", null ],
    [ "set_prot_flags_gen_code_x64", "class_e_l_f_adding_methods.html#ab5fee890e1e3e4ae015f328b12312275", null ],
    [ "set_prot_flags_gen_code_x86", "class_e_l_f_adding_methods.html#a2366eabcf1be00baed6d4e652c70cd99", null ],
    [ "wrapper_gen_code", "class_e_l_f_adding_methods.html#a5aba8ac68c5596fcd306563b3b1dc42d", null ],
    [ "placeholder_id", "class_e_l_f_adding_methods.html#a108205cdbf268927f0b64c2a783a96d5", null ],
    [ "placeholder_mnm", "class_e_l_f_adding_methods.html#ad77df886acfad79f1b705f5ff1976e4a", null ]
];