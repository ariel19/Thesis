var class_proc_out =
[
    [ "ProcOut", "class_proc_out.html#a32000573c7c559fcdfd68bcba443dd16", null ],
    [ "~ProcOut", "class_proc_out.html#a063492995249f724d970a454209f2197", null ],
    [ "finished", "class_proc_out.html#a1217c4df45842d54c438c2d94e979c63", null ],
    [ "readyRead", "class_proc_out.html#a74a10fb3b6a8648f145c9520300aa6fd", null ]
];