var daddingmethods_8h =
[
    [ "DAddingMethods", "class_d_adding_methods.html", "class_d_adding_methods" ],
    [ "Wrapper", "class_d_adding_methods_1_1_wrapper.html", "class_d_adding_methods_1_1_wrapper" ],
    [ "ThreadWrapper", "class_d_adding_methods_1_1_thread_wrapper.html", "class_d_adding_methods_1_1_thread_wrapper" ],
    [ "OEPWrapper", "class_d_adding_methods_1_1_o_e_p_wrapper.html", "class_d_adding_methods_1_1_o_e_p_wrapper" ],
    [ "TrampolineWrapper", "class_d_adding_methods_1_1_trampoline_wrapper.html", "class_d_adding_methods_1_1_trampoline_wrapper" ],
    [ "InjectDescription", "class_d_adding_methods_1_1_inject_description.html", "class_d_adding_methods_1_1_inject_description" ],
    [ "AsmCodeGenerator", "class_asm_code_generator.html", "class_asm_code_generator" ],
    [ "enum_stringify", "daddingmethods_8h.html#a9cdaa38dc2ea9f97e7169c4a05ab0ede", null ],
    [ "instruction_stringify", "daddingmethods_8h.html#a2dffee0b2992c6276c96aaa4ca719a21", null ],
    [ "mnemonic_stringify", "daddingmethods_8h.html#ac31b8fd4c17f82867884dfb116755859", null ]
];