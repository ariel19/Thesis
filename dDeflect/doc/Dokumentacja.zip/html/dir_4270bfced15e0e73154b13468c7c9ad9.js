var dir_4270bfced15e0e73154b13468c7c9ad9 =
[
    [ "adding_methods", "dir_115fc0fe4f4514b6057358768a3de513.html", "dir_115fc0fe4f4514b6057358768a3de513" ],
    [ "detection", "dir_1795b41ddd13162a07ba91047f9e7ecd.html", "dir_1795b41ddd13162a07ba91047f9e7ecd" ],
    [ "file_types", "dir_c1ba1c2b8a0e94bf76babf8745cc7d39.html", "dir_c1ba1c2b8a0e94bf76babf8745cc7d39" ],
    [ "sys_headers", "dir_5f7aec7a941464330633f197b42458d5.html", "dir_5f7aec7a941464330633f197b42458d5" ]
];