var dir_7c60b2f2d627f4e57214529fdf60ceae =
[
    [ "daddingmethods.cpp", "daddingmethods_8cpp.html", null ],
    [ "daddingmethods.h", "daddingmethods_8h.html", "daddingmethods_8h" ],
    [ "elfaddingmethods.cpp", "elfaddingmethods_8cpp.html", null ],
    [ "elfaddingmethods.h", "elfaddingmethods_8h.html", [
      [ "ELFAddingMethods", "class_e_l_f_adding_methods.html", "class_e_l_f_adding_methods" ]
    ] ],
    [ "peaddingmethods.cpp", "peaddingmethods_8cpp.html", null ],
    [ "peaddingmethods.h", "peaddingmethods_8h.html", [
      [ "PEAddingMethods", "class_p_e_adding_methods.html", "class_p_e_adding_methods" ]
    ] ]
];