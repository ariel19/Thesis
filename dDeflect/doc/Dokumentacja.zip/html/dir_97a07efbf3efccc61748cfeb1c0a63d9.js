var dir_97a07efbf3efccc61748cfeb1c0a63d9 =
[
    [ "DJsonParser", "dir_d48d5401775ad60ccdadf93090c42baf.html", "dir_d48d5401775ad60ccdadf93090c42baf" ],
    [ "DSourceCodeParser", "dir_ed3ba5bb5fa472116e507d031f576e8e.html", "dir_ed3ba5bb5fa472116e507d031f576e8e" ],
    [ "applicationmanager.cpp", "applicationmanager_8cpp.html", null ],
    [ "applicationmanager.h", "applicationmanager_8h.html", [
      [ "ApplicationManager", "class_application_manager.html", "class_application_manager" ]
    ] ]
];