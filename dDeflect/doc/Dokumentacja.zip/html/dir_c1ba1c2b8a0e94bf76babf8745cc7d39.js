var dir_c1ba1c2b8a0e94bf76babf8745cc7d39 =
[
    [ "binaryfile.cpp", "binaryfile_8cpp.html", null ],
    [ "binaryfile.h", "binaryfile_8h.html", [
      [ "BinaryFile", "class_binary_file.html", "class_binary_file" ]
    ] ],
    [ "codedefines.cpp", "codedefines_8cpp.html", null ],
    [ "codedefines.h", "codedefines_8h.html", "codedefines_8h" ],
    [ "elffile.cpp", "elffile_8cpp.html", "elffile_8cpp" ],
    [ "elffile.h", "elffile_8h.html", "elffile_8h" ],
    [ "pefile.cpp", "pefile_8cpp.html", null ],
    [ "pefile.h", "pefile_8h.html", [
      [ "PEFile", "class_p_e_file.html", "class_p_e_file" ],
      [ "RelocationTable", "struct_p_e_file_1_1_relocation_table.html", "struct_p_e_file_1_1_relocation_table" ],
      [ "TypeOffset", "struct_p_e_file_1_1_relocation_table_1_1_type_offset.html", "struct_p_e_file_1_1_relocation_table_1_1_type_offset" ]
    ] ],
    [ "pehelpers.cpp", "pehelpers_8cpp.html", null ],
    [ "pehelpers.h", "pehelpers_8h.html", null ]
];