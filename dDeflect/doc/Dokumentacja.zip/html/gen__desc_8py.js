var gen__desc_8py =
[
    [ "clean", "gen__desc_8py.html#a9e5c91910463053946db69a9d90b630c", null ],
    [ "generate_desc", "gen__desc_8py.html#a45ef70f111577d7d3068aa3324597e9d", null ],
    [ "get_config", "gen__desc_8py.html#a77d1ae4c78d40d8999644b2b2e3bf7d2", null ]
];