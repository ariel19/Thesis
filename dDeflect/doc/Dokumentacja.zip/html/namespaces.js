var namespaces =
[
    [ "gen_desc", "namespacegen__desc.html", null ]
];