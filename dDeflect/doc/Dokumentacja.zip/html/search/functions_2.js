var searchData=
[
  ['binarycode',['BinaryCode',['../class_binary_code.html#aa21721fc16b2e943be048fa3ceea300d',1,'BinaryCode']]],
  ['binaryfile',['BinaryFile',['../class_binary_file.html#a1afe5dffc5edf5f25ea22deef606eb4b',1,'BinaryFile']]]
];
