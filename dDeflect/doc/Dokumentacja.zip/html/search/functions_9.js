var searchData=
[
  ['injectcode',['injectCode',['../class_p_e_adding_methods.html#a2b224b51233e0446621e9daf9108e78b',1,'PEAddingMethods']]],
  ['injectepcode',['injectEpCode',['../class_p_e_adding_methods.html#a03c66cfef8c9a6aefb0166b63e501898',1,'PEAddingMethods::injectEpCode(QList&lt; uint64_t &gt; &amp;epMethods)'],['../class_p_e_adding_methods.html#a22067090f90a0b2fdbe8b127df0113e0',1,'PEAddingMethods::injectEpCode(QList&lt; uint64_t &gt; &amp;epMethods)'],['../class_p_e_adding_methods.html#a22067090f90a0b2fdbe8b127df0113e0',1,'PEAddingMethods::injectEpCode(QList&lt; uint64_t &gt; &amp;epMethods)']]],
  ['injecttlscode',['injectTlsCode',['../class_p_e_adding_methods.html#a16ab45ebef33f806f962985dbb921d54',1,'PEAddingMethods']]],
  ['injecttrampolinecode',['injectTrampolineCode',['../class_p_e_adding_methods.html#a7bfc807cbd6863be7a0caaab742668bb',1,'PEAddingMethods']]],
  ['injectuniquedata',['injectUniqueData',['../class_p_e_file.html#ab14d9fb29123545e0a7528795e64d3c1',1,'PEFile::injectUniqueData(BinaryCode&lt; Register &gt; data, QMap&lt; QByteArray, uint64_t &gt; &amp;ptrs, QList&lt; uint64_t &gt; &amp;relocations)'],['../class_p_e_file.html#a6bea21405c1aab9b4e3d43d980a5aac5',1,'PEFile::injectUniqueData(QByteArray data, QMap&lt; QByteArray, uint64_t &gt; &amp;ptrs, bool *inserted=NULL)']]],
  ['insertmethods',['insertMethods',['../class_application_manager.html#ace0c5e4596d968278acd0b61042472d2',1,'ApplicationManager::insertMethods()'],['../class_d_source_code_parser.html#acb80a33d6f64af51009f3a09fbfd430b',1,'DSourceCodeParser::insertMethods()']]],
  ['internalregs',['internalRegs',['../class_code_defines.html#accadab674c6c55403b54ffb679ccdf62',1,'CodeDefines::internalRegs'],['../class_code_defines.html#a0901fe2185ed5ffc391ee5c1e4a14b7a',1,'CodeDefines::internalRegs']]],
  ['is_5fvalid',['is_valid',['../class_binary_file.html#a6007435bc4451bb80a3169d977f4f125',1,'BinaryFile::is_valid()'],['../class_e_l_f.html#aaf0da9f62b61fc3674b7fd54d9885b5f',1,'ELF::is_valid()'],['../class_p_e_file.html#a90a96d95f9d67ff48bf12ffcb0f22d41',1,'PEFile::is_valid()']]],
  ['is_5fx64',['is_x64',['../class_binary_file.html#a36b7998c72bbee68ab492d93368c14ca',1,'BinaryFile::is_x64()'],['../class_e_l_f.html#a558b2f169db21b21b24d6ff19c38ac9e',1,'ELF::is_x64()'],['../class_p_e_file.html#aa8e69bdca4d00216df406278b4e96a28',1,'PEFile::is_x64()']]],
  ['is_5fx86',['is_x86',['../class_binary_file.html#aa7d43cde4ab8cc9723d2b5c769719bd9',1,'BinaryFile::is_x86()'],['../class_e_l_f.html#ac5c89b2b437f3e07aedc06f66cdab94d',1,'ELF::is_x86()'],['../class_p_e_file.html#a371cc84eed9dd5d85b7c50d60c1eb56f',1,'PEFile::is_x86()']]],
  ['ispe_5f64',['isPE_64',['../class_p_e_file.html#aa415803ce1fbb7e807e568ce25121515',1,'PEFile']]],
  ['issectionexecutable',['isSectionExecutable',['../class_p_e_file.html#a13b95be1db5cb677e28c85b03f08e5c0',1,'PEFile']]],
  ['issectionrawdataempty',['isSectionRawDataEmpty',['../class_p_e_file.html#ab5ab5850cce8abcb48c89e0fa44901ca',1,'PEFile']]]
];
