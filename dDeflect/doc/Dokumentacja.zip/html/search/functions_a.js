var searchData=
[
  ['jmp_5freg',['jmp_reg',['../class_asm_code_generator.html#ac196b01980e9de00bf6854baed99a1a2',1,'AsmCodeGenerator']]],
  ['jmpreg',['jmpReg',['../class_code_defines.html#a5553e8054d6bb237d69a2393c6892484',1,'CodeDefines']]],
  ['jmprelative',['jmpRelative',['../class_code_defines.html#aff433a64828802d6500a26769b3696be',1,'CodeDefines']]],
  ['jzrelative',['jzRelative',['../class_code_defines.html#ad92e4b0ee88740626ad9e73b0b170a14',1,'CodeDefines']]]
];
