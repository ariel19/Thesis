var struct___i_m_a_g_e___b_a_s_e___r_e_l_o_c_a_t_i_o_n =
[
    [ "SizeOfBlock", "struct___i_m_a_g_e___b_a_s_e___r_e_l_o_c_a_t_i_o_n.html#a81d20c4bdef7268e328159bbc56e2d76", null ],
    [ "VirtualAddress", "struct___i_m_a_g_e___b_a_s_e___r_e_l_o_c_a_t_i_o_n.html#aa9cd235a62c0b36e0b9f7051be3c5dcb", null ]
];