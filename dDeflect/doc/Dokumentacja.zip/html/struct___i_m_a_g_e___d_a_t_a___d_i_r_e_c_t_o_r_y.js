var struct___i_m_a_g_e___d_a_t_a___d_i_r_e_c_t_o_r_y =
[
    [ "Size", "struct___i_m_a_g_e___d_a_t_a___d_i_r_e_c_t_o_r_y.html#ab5bfce429cb0243cdc216f514108aa85", null ],
    [ "VirtualAddress", "struct___i_m_a_g_e___d_a_t_a___d_i_r_e_c_t_o_r_y.html#a4367862469fd1ea60088ae02b1b6df70", null ]
];