var struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r =
[
    [ "e_cblp", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a1bd42856267579ce345e062eca7545c5", null ],
    [ "e_cp", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#aaaa4b40f12deb3c4d6b23d106c3bfbce", null ],
    [ "e_cparhdr", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a880d14ac887440a6859c45a5b6c7db0c", null ],
    [ "e_crlc", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a9c7b1e78d0a6491d4fa41363b5aefecc", null ],
    [ "e_cs", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a7a8521e4ed5d09008750824d2cf1b4cd", null ],
    [ "e_csum", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a43bd3860e13131189379e878d5ca7052", null ],
    [ "e_ip", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#acd7c90273207e7c4067989e7cf3569f8", null ],
    [ "e_lfanew", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#adf342409a54c9b3acdfc2aaeb1f10ba8", null ],
    [ "e_lfarlc", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a5fbd4e1819caa5f1032568eb2def6cb0", null ],
    [ "e_magic", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a2395379130b4cc7d2d3e6982e6e3fc4c", null ],
    [ "e_maxalloc", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a65684758e3524a791a7a818322b57eea", null ],
    [ "e_minalloc", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a5a82bb159167fe8e23fbbc06ffb85b2c", null ],
    [ "e_oemid", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#ab81146b886293ed9937ff88189e87f7e", null ],
    [ "e_oeminfo", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a07dfa12b29293ba9cc6b885bce094099", null ],
    [ "e_ovno", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a8aeaa7307372906be09e32dc2b1901d0", null ],
    [ "e_res", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#a73c26e0cd458c8b94dcb05c8e8597fd9", null ],
    [ "e_res2", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#af865555510423e60e04abfd1626d8474", null ],
    [ "e_sp", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#abdf58356f1ed49b4e06935a51b8b6063", null ],
    [ "e_ss", "struct___i_m_a_g_e___d_o_s___h_e_a_d_e_r.html#ae8cba7f40bb926f2218808e7bc2a5965", null ]
];