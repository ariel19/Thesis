var struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r =
[
    [ "Characteristics", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#a121e0ec6d4ce2ea021df48f6949956c3", null ],
    [ "Machine", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#aadde4ef78693fa8d4bc1c97c7d3c8c1a", null ],
    [ "NumberOfSections", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#ad604cffb35b69981158822e14e9bc1c0", null ],
    [ "NumberOfSymbols", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#a3e054c70bc25a6797608fb32327348ad", null ],
    [ "PointerToSymbolTable", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#a5c3f6aef5cd87caa9d5ce887aaf2e522", null ],
    [ "SizeOfOptionalHeader", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#a7fc97339de25b2845ef855809be630ff", null ],
    [ "TimeDateStamp", "struct___i_m_a_g_e___f_i_l_e___h_e_a_d_e_r.html#af36d3522f4749a93453bde62c0f7732b", null ]
];