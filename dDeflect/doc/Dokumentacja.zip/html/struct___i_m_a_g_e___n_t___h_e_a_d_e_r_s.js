var struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s =
[
    [ "FileHeader", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s.html#ab8aa7ee8ecc7b35fecc1b99b57fc9817", null ],
    [ "OptionalHeader", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s.html#a71de2ed0819a8fac537db2e9daedfe05", null ],
    [ "Signature", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s.html#a0fab671e499d3d3f47db0a30b8369f80", null ]
];