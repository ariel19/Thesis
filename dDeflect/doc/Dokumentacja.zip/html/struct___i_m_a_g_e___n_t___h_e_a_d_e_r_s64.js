var struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s64 =
[
    [ "FileHeader", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s64.html#a90697a3d56043dee58cbf21b30363863", null ],
    [ "OptionalHeader", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s64.html#a50eaffc01bf927048dc730c15b5ed3f1", null ],
    [ "Signature", "struct___i_m_a_g_e___n_t___h_e_a_d_e_r_s64.html#a846d3eb78fd95dc71db36e89269d81cb", null ]
];