var struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r =
[
    [ "Characteristics", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a5f031b627355f5c2c5412c522280656b", null ],
    [ "Misc", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a22c8f85326fe46618b630841d07a4afd", null ],
    [ "Name", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#acdad09df74f03f4e7611b735edbff5f8", null ],
    [ "NumberOfLinenumbers", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#aace0e3a76840601729527faff6c55f49", null ],
    [ "NumberOfRelocations", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#ab49e4f9170d85a8cd78ab0acf2fcef2a", null ],
    [ "PhysicalAddress", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#acd4b267168f34a33618c57c4446e5d0c", null ],
    [ "PointerToLinenumbers", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a38bf032a66c8906adca8cb45e4e049b5", null ],
    [ "PointerToRawData", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a7581621fab8f326e12f31a5577896a71", null ],
    [ "PointerToRelocations", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a6d59f7e4cff74f3951a7da37454b9084", null ],
    [ "SizeOfRawData", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#a376d19b94bc4c71dc887ec7067e60025", null ],
    [ "VirtualAddress", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#ab0f0e24d6b0a17680e8609a608a0d530", null ],
    [ "VirtualSize", "struct___i_m_a_g_e___s_e_c_t_i_o_n___h_e_a_d_e_r.html#ae141e4583b36e2ea9b564b420e7e7c49", null ]
];