var struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32 =
[
    [ "AddressOfCallBacks", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#ac2b279a00258cd0599dbb88e1f086d82", null ],
    [ "AddressOfIndex", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#a45bba3580baa7a89ec66ca4aa29cdc3b", null ],
    [ "Characteristics", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#a8428d0a94518288a8ae357f2be87052f", null ],
    [ "EndAddressOfRawData", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#aff760067d4ededf860bb717d4de97745", null ],
    [ "SizeOfZeroFill", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#aa9746f752a09d2c5cace07a133a676fd", null ],
    [ "StartAddressOfRawData", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y32.html#a132e912376ff214a7ca2df977890c58d", null ]
];