var struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64 =
[
    [ "AddressOfCallBacks", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#a452bbe7cedad14cf65c398c431b1eaab", null ],
    [ "AddressOfIndex", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#aeb338678cb68dc21f9cecf8852c8612c", null ],
    [ "Characteristics", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#a0679b478596e1c465f5110c8b610de23", null ],
    [ "EndAddressOfRawData", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#ab61fb7c9f49cd50d98edb94ab1aeea4f", null ],
    [ "SizeOfZeroFill", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#a559c7786966fb5feb444c670e75a273a", null ],
    [ "StartAddressOfRawData", "struct___i_m_a_g_e___t_l_s___d_i_r_e_c_t_o_r_y64.html#a7ee64440f81908fc6aacc04547651c9a", null ]
];