var struct_elf32___ehdr =
[
    [ "e_ehsize", "struct_elf32___ehdr.html#a04c658023e50479eed64f6d1b00a2504", null ],
    [ "e_entry", "struct_elf32___ehdr.html#ab8a982696048d807017919b7d0145482", null ],
    [ "e_flags", "struct_elf32___ehdr.html#a87cf481be7917fafde0c4ecf78c8e574", null ],
    [ "e_ident", "struct_elf32___ehdr.html#aba47ac5e0af02d5668782f1fd5a7466c", null ],
    [ "e_machine", "struct_elf32___ehdr.html#a19bca7faba9e5573814643efc3574c7b", null ],
    [ "e_phentsize", "struct_elf32___ehdr.html#afa2289f96d86fcc568a3b1f40cc8953e", null ],
    [ "e_phnum", "struct_elf32___ehdr.html#a360898812db1655f8cb8258780d9df5b", null ],
    [ "e_phoff", "struct_elf32___ehdr.html#a25c36fc010284a928604aae005b67ad1", null ],
    [ "e_shentsize", "struct_elf32___ehdr.html#ab53c709a841960e499da68e2316ed428", null ],
    [ "e_shnum", "struct_elf32___ehdr.html#a11249bd7e61642742a68a3e7f69ac721", null ],
    [ "e_shoff", "struct_elf32___ehdr.html#a00601af5187a1b3f8babfe9cddd95c15", null ],
    [ "e_shstrndx", "struct_elf32___ehdr.html#a3b3070ccd7d971e8cb6ea58d4c6fab09", null ],
    [ "e_type", "struct_elf32___ehdr.html#a49e40a791813c06e3b6ebcb53aef1bb8", null ],
    [ "e_version", "struct_elf32___ehdr.html#aa27627bda53281221325df4dd782e800", null ]
];