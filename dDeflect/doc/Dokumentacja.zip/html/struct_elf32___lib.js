var struct_elf32___lib =
[
    [ "l_checksum", "struct_elf32___lib.html#a290248b0a3cecff9d43f796dd5c50b12", null ],
    [ "l_flags", "struct_elf32___lib.html#a4a0feb8162591596d3653f561ee8759e", null ],
    [ "l_name", "struct_elf32___lib.html#af40827a2882aaf96d42ae60dac6551ee", null ],
    [ "l_time_stamp", "struct_elf32___lib.html#ae7119079569dcf7ecebccc47cb6350be", null ],
    [ "l_version", "struct_elf32___lib.html#ab1be8296800ef7b233adb56f1cfb901c", null ]
];