var struct_elf32___nhdr =
[
    [ "n_descsz", "struct_elf32___nhdr.html#ad83450c86fb3e14d1096a141ea705f33", null ],
    [ "n_namesz", "struct_elf32___nhdr.html#a8e6389f882a5c695518a833b4c1bd9c6", null ],
    [ "n_type", "struct_elf32___nhdr.html#afdab20b47522cb964500a200ceb92462", null ]
];