var struct_elf32___phdr =
[
    [ "p_align", "struct_elf32___phdr.html#afd09d9e4297b13fc94fd57d09f2a9f70", null ],
    [ "p_filesz", "struct_elf32___phdr.html#ac9151f2e11001284bf1c7d2d2659555c", null ],
    [ "p_flags", "struct_elf32___phdr.html#a35c457e6828894b7b275730593802050", null ],
    [ "p_memsz", "struct_elf32___phdr.html#ada1cdd3d6ccb79a17bed0e3c21379c84", null ],
    [ "p_offset", "struct_elf32___phdr.html#ac590d4c4b26104216e53058b5b03eef0", null ],
    [ "p_paddr", "struct_elf32___phdr.html#af18f0a179a5fca09e3c04bcdce3fac2f", null ],
    [ "p_type", "struct_elf32___phdr.html#a8b1d2942ddb9abcb85db1429b5116923", null ],
    [ "p_vaddr", "struct_elf32___phdr.html#a01a298ebc899bcf9c23211a7bf1155a6", null ]
];