var struct_elf32___reg_info =
[
    [ "ri_cprmask", "struct_elf32___reg_info.html#a42ab40af79e7bbfb3122546aa99824a8", null ],
    [ "ri_gp_value", "struct_elf32___reg_info.html#ae464ec715b979270bedadc8889f94a16", null ],
    [ "ri_gprmask", "struct_elf32___reg_info.html#a14e7256134e34950e4fb5681d77dd353", null ]
];