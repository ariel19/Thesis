var struct_elf32___rel =
[
    [ "r_info", "struct_elf32___rel.html#a81c52bb1589056c5d37d58b9bfe2a046", null ],
    [ "r_offset", "struct_elf32___rel.html#addcf5ef67ababeb4940889e912c11eff", null ]
];