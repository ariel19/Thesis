var struct_elf32___shdr =
[
    [ "sh_addr", "struct_elf32___shdr.html#a7e668a62cee74a2f9c6edabb5f45635a", null ],
    [ "sh_addralign", "struct_elf32___shdr.html#a399f50b3591e6286d4ad819f790979ed", null ],
    [ "sh_entsize", "struct_elf32___shdr.html#a10c59cecc928aae27930601fe545d3ca", null ],
    [ "sh_flags", "struct_elf32___shdr.html#a27e003d8da37de3038a0065577a7743d", null ],
    [ "sh_info", "struct_elf32___shdr.html#aef63fe62c2c9927f374c4f987954c6e5", null ],
    [ "sh_link", "struct_elf32___shdr.html#ad759308388eb14c5c6e4d636c38999da", null ],
    [ "sh_name", "struct_elf32___shdr.html#a6e8fd300ca473a31d0f65817ce371dfd", null ],
    [ "sh_offset", "struct_elf32___shdr.html#a6e37227a5777cddc0a9dbbb3c2598ec1", null ],
    [ "sh_size", "struct_elf32___shdr.html#a84dc67bb0ab65880bbcd74fbee722ff1", null ],
    [ "sh_type", "struct_elf32___shdr.html#aab6c221dbd7e16987df41280fb915408", null ]
];