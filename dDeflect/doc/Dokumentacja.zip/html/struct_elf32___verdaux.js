var struct_elf32___verdaux =
[
    [ "vda_name", "struct_elf32___verdaux.html#a5cec12aee4339964d8956351465efa51", null ],
    [ "vda_next", "struct_elf32___verdaux.html#ab3814a03060eab7d93f1f79d93d3fedd", null ]
];