var struct_elf32___verdef =
[
    [ "vd_aux", "struct_elf32___verdef.html#a3693473efde66cb13cecda2053c91f9d", null ],
    [ "vd_cnt", "struct_elf32___verdef.html#a38c7ed683760f798e42ff3c411ea23ba", null ],
    [ "vd_flags", "struct_elf32___verdef.html#a782382383f96808eeddb86e3db2737c3", null ],
    [ "vd_hash", "struct_elf32___verdef.html#aed64e7dede5f8150f10457c420b48416", null ],
    [ "vd_ndx", "struct_elf32___verdef.html#afcaa14f5175bb38ecb6ef832c2aa2232", null ],
    [ "vd_next", "struct_elf32___verdef.html#ac919bdca49dff2f3a04b1328903edb71", null ],
    [ "vd_version", "struct_elf32___verdef.html#ad2f222a352ff9e2d92199811ff094822", null ]
];