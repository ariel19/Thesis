var struct_elf32___vernaux =
[
    [ "vna_flags", "struct_elf32___vernaux.html#a4da8f50d1625f6cf7a0c3415e94958fb", null ],
    [ "vna_hash", "struct_elf32___vernaux.html#aeae097b35e2038c53eabb3fe3e0c7bf1", null ],
    [ "vna_name", "struct_elf32___vernaux.html#a8bf6007fe319d74753d03d0fa7977002", null ],
    [ "vna_next", "struct_elf32___vernaux.html#acff2104085a8a54ccbb16b0f00be5375", null ],
    [ "vna_other", "struct_elf32___vernaux.html#a28f6da095d6169a589ab3bad837258fc", null ]
];