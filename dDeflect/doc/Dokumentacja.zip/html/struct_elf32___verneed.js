var struct_elf32___verneed =
[
    [ "vn_aux", "struct_elf32___verneed.html#a0db7ff11ee775f27ebb1e10a6affabb8", null ],
    [ "vn_cnt", "struct_elf32___verneed.html#a8c8c56b63ee1f38cf5568fa7bd5b4f73", null ],
    [ "vn_file", "struct_elf32___verneed.html#a71c12598274c795cca809b99462e062a", null ],
    [ "vn_next", "struct_elf32___verneed.html#ae3819b6239b81ed5c8ce4f8710176870", null ],
    [ "vn_version", "struct_elf32___verneed.html#ae87cf6c64587fcf3cd80ba2f6aa6b1bb", null ]
];