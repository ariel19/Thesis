var struct_elf64___dyn =
[
    [ "d_ptr", "struct_elf64___dyn.html#a4820e579b624438f02827e7b44fbd0f7", null ],
    [ "d_tag", "struct_elf64___dyn.html#a74a63e5acb7d8ddc946a5b0c5eb3c26a", null ],
    [ "d_un", "struct_elf64___dyn.html#acc39d52f3a8efd552afa2e3369c03215", null ],
    [ "d_val", "struct_elf64___dyn.html#ab1741378fc34cbcc8caf3f7bb5e6de18", null ]
];