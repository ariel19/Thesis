var struct_elf64___ehdr =
[
    [ "e_ehsize", "struct_elf64___ehdr.html#a404b7e3566d912b0382cacea17475e92", null ],
    [ "e_entry", "struct_elf64___ehdr.html#a943c7d038a3cc3c1115e84b4cd19966d", null ],
    [ "e_flags", "struct_elf64___ehdr.html#ae6ea9e821472d35e7d2c446fa79bdc3a", null ],
    [ "e_ident", "struct_elf64___ehdr.html#acdd2e122af003c5b5708d1ae75b4a85c", null ],
    [ "e_machine", "struct_elf64___ehdr.html#adecc8b3641e23794f39c78f15ab8c809", null ],
    [ "e_phentsize", "struct_elf64___ehdr.html#ab5aefb7a14b9cf2eafcbaf0664852369", null ],
    [ "e_phnum", "struct_elf64___ehdr.html#af13bac5685d725c2ba9930c1176f3082", null ],
    [ "e_phoff", "struct_elf64___ehdr.html#adc7d13d5c0e0eb4b62f0f898f03b2e66", null ],
    [ "e_shentsize", "struct_elf64___ehdr.html#a078af1eaf7681f9d85ff545b6c7aa9c5", null ],
    [ "e_shnum", "struct_elf64___ehdr.html#a317679f1ef5e41e0717e95670c6a1d24", null ],
    [ "e_shoff", "struct_elf64___ehdr.html#a63fca3f9b273e5fd4d190d9cb7fba9b0", null ],
    [ "e_shstrndx", "struct_elf64___ehdr.html#ae8289d7705794be744876f6246242b9b", null ],
    [ "e_type", "struct_elf64___ehdr.html#a031210e6571dad798c4ed66b85631d58", null ],
    [ "e_version", "struct_elf64___ehdr.html#a3855471cf08a9e4cd4b898e9a1e11fa4", null ]
];