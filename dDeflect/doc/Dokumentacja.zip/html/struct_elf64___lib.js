var struct_elf64___lib =
[
    [ "l_checksum", "struct_elf64___lib.html#a11f09b77bcae792d5e5c120b4a0fbcca", null ],
    [ "l_flags", "struct_elf64___lib.html#ac78fa7eafc377b04fcaf575c61dc2b60", null ],
    [ "l_name", "struct_elf64___lib.html#ac7f21d23c86f56c6583aa563eb960af0", null ],
    [ "l_time_stamp", "struct_elf64___lib.html#ace001f85c3f31e91fedf4a1a1f923af5", null ],
    [ "l_version", "struct_elf64___lib.html#ab03d7034a6f1113717a9eefe33cb8343", null ]
];