var struct_elf64___nhdr =
[
    [ "n_descsz", "struct_elf64___nhdr.html#ace700cd855c773a6483e247f18a33350", null ],
    [ "n_namesz", "struct_elf64___nhdr.html#a1169a3f8272ba5265ea3aecdc4974546", null ],
    [ "n_type", "struct_elf64___nhdr.html#abbb820712cc219d235bb7eb3c11eefbe", null ]
];