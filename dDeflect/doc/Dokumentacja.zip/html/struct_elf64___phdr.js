var struct_elf64___phdr =
[
    [ "p_align", "struct_elf64___phdr.html#aa89a4b1835998c8866e821d777a2f879", null ],
    [ "p_filesz", "struct_elf64___phdr.html#af50e5756da2acda5ccb02ebaa3367092", null ],
    [ "p_flags", "struct_elf64___phdr.html#ab96e7784733c2192a76d5a42897cb38b", null ],
    [ "p_memsz", "struct_elf64___phdr.html#a55fae01175fc4e3f1c23e52b14459235", null ],
    [ "p_offset", "struct_elf64___phdr.html#aa2d51fb4517ded0c74903f8d0c9abea7", null ],
    [ "p_paddr", "struct_elf64___phdr.html#a83f4adb032fc307f5af79bdee5ef692d", null ],
    [ "p_type", "struct_elf64___phdr.html#aee6ec430eaaf8b8faf82ae6397282cb3", null ],
    [ "p_vaddr", "struct_elf64___phdr.html#a5c69879e1229b175020ff011af46fcb9", null ]
];