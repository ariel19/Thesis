var struct_elf64___rel =
[
    [ "r_info", "struct_elf64___rel.html#a775740962c9bd1e3f956bd8bffca173b", null ],
    [ "r_offset", "struct_elf64___rel.html#af719169bd59569a885bf9d5df794b951", null ]
];