var struct_elf64___shdr =
[
    [ "sh_addr", "struct_elf64___shdr.html#ac4ee2ceaec74ab5704ebba226e83b200", null ],
    [ "sh_addralign", "struct_elf64___shdr.html#ab6b9f67208a04cc0d374203c0a3ab93a", null ],
    [ "sh_entsize", "struct_elf64___shdr.html#a879406e9ddf2bd7e45346d430d0aaa44", null ],
    [ "sh_flags", "struct_elf64___shdr.html#a20aab677eb99c91c0e6c3c5dc8f0f3db", null ],
    [ "sh_info", "struct_elf64___shdr.html#a72dd754689db27582817c0691f7d0c77", null ],
    [ "sh_link", "struct_elf64___shdr.html#a29812c42d9310eb3ad17dcd68ec25536", null ],
    [ "sh_name", "struct_elf64___shdr.html#a18f4475eeec871316099323b512d999d", null ],
    [ "sh_offset", "struct_elf64___shdr.html#afd5e899b00b6527bbecf9cd4bda50112", null ],
    [ "sh_size", "struct_elf64___shdr.html#a8988fd6e383835e9d51344eddf38ef24", null ],
    [ "sh_type", "struct_elf64___shdr.html#a6379cd77214969499ae99e6e8a46405c", null ]
];