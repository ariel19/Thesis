var struct_elf64___syminfo =
[
    [ "si_boundto", "struct_elf64___syminfo.html#a919d1c0dd96fae4b828902b765097e15", null ],
    [ "si_flags", "struct_elf64___syminfo.html#a919ad3ae58e391cb2cf9da819d9d1344", null ]
];