var struct_elf64___verdaux =
[
    [ "vda_name", "struct_elf64___verdaux.html#a76ef57da3e7a6f477d867b378dd976ce", null ],
    [ "vda_next", "struct_elf64___verdaux.html#a550488ec793293fb872d8ec696faf9ff", null ]
];