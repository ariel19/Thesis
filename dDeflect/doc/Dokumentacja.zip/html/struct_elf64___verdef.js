var struct_elf64___verdef =
[
    [ "vd_aux", "struct_elf64___verdef.html#ae59893f742edf4e58e2acd78a1168aa3", null ],
    [ "vd_cnt", "struct_elf64___verdef.html#ac41468980738fcc6b1b15ccda97a19a8", null ],
    [ "vd_flags", "struct_elf64___verdef.html#a1d69114c03f683d4b6b6f3a83c7021f1", null ],
    [ "vd_hash", "struct_elf64___verdef.html#afb01f82af6211a4a0dfc314c3b3a43b2", null ],
    [ "vd_ndx", "struct_elf64___verdef.html#a069835dc20ac41af0ac611eefbe5169a", null ],
    [ "vd_next", "struct_elf64___verdef.html#a9cebd5131a542990d3130489a3b4acec", null ],
    [ "vd_version", "struct_elf64___verdef.html#afe15c8d72df394443deb40da61df3459", null ]
];