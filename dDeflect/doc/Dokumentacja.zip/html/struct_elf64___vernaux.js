var struct_elf64___vernaux =
[
    [ "vna_flags", "struct_elf64___vernaux.html#a1c5aa72ab842b4338ba2576d5f014700", null ],
    [ "vna_hash", "struct_elf64___vernaux.html#ae41cce47b72e2232f3880843ab550649", null ],
    [ "vna_name", "struct_elf64___vernaux.html#a4c83e76a256ad7fe7058df7ee9493c5c", null ],
    [ "vna_next", "struct_elf64___vernaux.html#a565bd1e8b3ae2f45854f8163629444fc", null ],
    [ "vna_other", "struct_elf64___vernaux.html#a56e3d7fee69c7b55556297757e1977e5", null ]
];