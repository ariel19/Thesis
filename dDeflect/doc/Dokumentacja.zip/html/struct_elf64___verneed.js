var struct_elf64___verneed =
[
    [ "vn_aux", "struct_elf64___verneed.html#a0b9d3ccbab06cb391f169987b1dbff0f", null ],
    [ "vn_cnt", "struct_elf64___verneed.html#ab8bae5b901cc7007685f35d43cf63884", null ],
    [ "vn_file", "struct_elf64___verneed.html#acb9149fec79d7eefb3f1d6300be2125f", null ],
    [ "vn_next", "struct_elf64___verneed.html#a8036329a9f5ad3a4006f16cbe3c9e866", null ],
    [ "vn_version", "struct_elf64___verneed.html#abbe3d560e7f69253f3c468f2c9d30f99", null ]
];