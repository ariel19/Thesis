var struct_elf64__auxv__t =
[
    [ "a_type", "struct_elf64__auxv__t.html#aa4799367aa86aa03c70a44148b14d000", null ],
    [ "a_un", "struct_elf64__auxv__t.html#a988fa43fd867a7c0b571fa9f505ecc1c", null ],
    [ "a_val", "struct_elf64__auxv__t.html#ae9741865b74b4fbe872d5de874feb207", null ]
];