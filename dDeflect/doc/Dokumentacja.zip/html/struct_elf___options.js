var struct_elf___options =
[
    [ "info", "struct_elf___options.html#a4d25edb0432aa63eda00cb607ae389eb", null ],
    [ "kind", "struct_elf___options.html#a3732e1185baf21c513ee7618d334d8c5", null ],
    [ "section", "struct_elf___options.html#a87449701f0810aa950517897da8ad747", null ],
    [ "size", "struct_elf___options.html#a9a66f1e3a53f76858d3520f151864744", null ]
];