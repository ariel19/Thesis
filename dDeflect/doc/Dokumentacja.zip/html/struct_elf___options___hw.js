var struct_elf___options___hw =
[
    [ "hwp_flags1", "struct_elf___options___hw.html#ade844ca291219a4c2ddb9daa5ff7cdc1", null ],
    [ "hwp_flags2", "struct_elf___options___hw.html#a4940c510ca6158e2ea1df247ffce5882", null ]
];