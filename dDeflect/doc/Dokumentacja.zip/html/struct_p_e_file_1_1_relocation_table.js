var struct_p_e_file_1_1_relocation_table =
[
    [ "TypeOffset", "struct_p_e_file_1_1_relocation_table_1_1_type_offset.html", "struct_p_e_file_1_1_relocation_table_1_1_type_offset" ],
    [ "addOffset", "struct_p_e_file_1_1_relocation_table.html#afd8b0b16ce56bd171f26c5e202ab3bd6", null ],
    [ "toBytes", "struct_p_e_file_1_1_relocation_table.html#ab4ffcdaf0bb39d4042dcab51436300fa", null ],
    [ "SizeOfBlock", "struct_p_e_file_1_1_relocation_table.html#ae28c64748e1a56f5ac2c30ca49c0775c", null ],
    [ "TypeOffsets", "struct_p_e_file_1_1_relocation_table.html#a28a0ecf5477d11bbdb1fabc2fce24e64", null ],
    [ "VirtualAddress", "struct_p_e_file_1_1_relocation_table.html#aeb4180a2c4aac556753407e081bde7db", null ]
];