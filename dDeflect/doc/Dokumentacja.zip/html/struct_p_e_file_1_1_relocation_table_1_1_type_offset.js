var struct_p_e_file_1_1_relocation_table_1_1_type_offset =
[
    [ "Offset", "struct_p_e_file_1_1_relocation_table_1_1_type_offset.html#a5b5bdeee7b3fae781cbbc48242dfc453", null ],
    [ "Type", "struct_p_e_file_1_1_relocation_table_1_1_type_offset.html#a1d812b2e05780019bb9bb44d6fb1a3db", null ]
];