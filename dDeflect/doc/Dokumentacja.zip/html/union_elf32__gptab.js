var union_elf32__gptab =
[
    [ "gt_bytes", "union_elf32__gptab.html#a1af9c483170a1b9e966d4c728934c7e0", null ],
    [ "gt_current_g_value", "union_elf32__gptab.html#a89ae523fa83704dc11651942f14b23f3", null ],
    [ "gt_entry", "union_elf32__gptab.html#af0c0a5a25eff0b2129de1589a3eb6841", null ],
    [ "gt_g_value", "union_elf32__gptab.html#a5c6035560c772d9b020e5110dbb435b8", null ],
    [ "gt_header", "union_elf32__gptab.html#a441c6711b23ee48ff59b9e42287d146b", null ],
    [ "gt_unused", "union_elf32__gptab.html#aefa9e4dcc4bff4e59999b01f0bc790bf", null ]
];